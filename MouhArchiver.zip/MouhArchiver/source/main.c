/*
 * MouhArchiver - step 1: file browser
 * PSL1GHT + freetype (software rendering into the RSX framebuffer)
 *
 * Controls:  UP/DOWN = move   L1/R1 = jump 10   X = open folder
 *            O or TRIANGLE = back   START = exit
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <malloc.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

#include <ppu-types.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <rsx/rsx.h>
#include <io/pad.h>

#include <ft2build.h>
#include FT_FREETYPE_H

#define CB_SIZE     0x100000
#define HOST_SIZE   (32 * 1024 * 1024)
#define MAX_ENTRIES 4096

/* Colors 0x00RRGGBB */
#define COL_BG      0x1B2420
#define COL_ROW_A   0x222C27
#define COL_ROW_B   0x1E2823
#define COL_GREEN   0x6AAB2E
#define COL_DARKGRN 0x3F6B1A
#define COL_TEXT    0xEEEEEE
#define COL_DIM     0xA0AAA4
#define COL_FOLDER  0xE8C547

/* ---------- screen ---------- */
static gcmContextData *ctx;
static u32 *fb[2];
static u32 fb_off[2];
static int curfb = 0, first_flip = 1;
static u32 W, H;
static u32 *back;

static int S(int v) { return v * (int)H / 720; }   /* scale from 720p */

static void init_screen(void)
{
    void *host = memalign(1024 * 1024, HOST_SIZE);
    rsxInit(&ctx, CB_SIZE, HOST_SIZE, host);

    videoState st;
    videoGetState(0, 0, &st);

    videoResolution res;
    videoGetResolution(st.displayMode.resolution, &res);

    videoConfiguration vc;
    memset(&vc, 0, sizeof(vc));
    vc.resolution = st.displayMode.resolution;
    vc.format = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch = res.width * 4;
    videoConfigure(0, &vc, NULL, 0);
    videoGetState(0, 0, &st);

    gcmSetFlipMode(GCM_FLIP_VSYNC);
    W = res.width;
    H = res.height;

    for (int i = 0; i < 2; i++) {
        fb[i] = (u32 *)rsxMemalign(64, W * H * 4);
        rsxAddressToOffset(fb[i], &fb_off[i]);
        gcmSetDisplayBuffer(i, fb_off[i], W * 4, W, H);
    }
    gcmResetFlipStatus();
    back = fb[curfb];
}

static void wait_flip(void)
{
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static void flip(void)
{
    if (!first_flip) wait_flip();
    else { gcmResetFlipStatus(); first_flip = 0; }

    gcmSetFlip(ctx, curfb);
    rsxFlushBuffer(ctx);
    gcmSetWaitFlip(ctx);

    curfb ^= 1;
    back = fb[curfb];
}

/* ---------- drawing ---------- */
static void fill_rect(int x, int y, int w, int h, u32 col)
{
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > (int)W) w = W - x;
    if (y + h > (int)H) h = H - y;
    for (int j = 0; j < h; j++) {
        u32 *p = back + (y + j) * W + x;
        for (int i = 0; i < w; i++) p[i] = col;
    }
}

static FT_Library ft;
static FT_Face face = NULL;

static void init_font(void)
{
    static const char *paths[] = {
        "/dev_flash/data/font/SCE-PS3-SR-R-LATIN.TTF",
        "/dev_flash/data/font/SCE-PS3-VR-R-LATIN.TTF",
        "/dev_flash/data/font/SCE-PS3-RD-R-LATIN.TTF",
        "/dev_flash/data/font/SCE-PS3-DH-R-CGB.TTF",
        NULL
    };
    if (FT_Init_FreeType(&ft)) return;
    for (int i = 0; paths[i]; i++) {
        if (FT_New_Face(ft, paths[i], 0, &face) == 0) {
            FT_Set_Pixel_Sizes(face, 0, S(22));
            return;
        }
        face = NULL;
    }
}

static int text_width(const char *s)
{
    if (!face) return 0;
    int w = 0;
    for (; *s; s++) {
        if (FT_Load_Char(face, (unsigned char)*s, FT_LOAD_DEFAULT)) continue;
        w += face->glyph->advance.x >> 6;
    }
    return w;
}

/* y = baseline. maxw <= 0 means no limit. */
static void draw_text(int x, int y, const char *s, u32 col, int maxw)
{
    if (!face) return;
    int x0 = x;
    int cr = (col >> 16) & 255, cg = (col >> 8) & 255, cb = col & 255;

    for (; *s; s++) {
        if (FT_Load_Char(face, (unsigned char)*s, FT_LOAD_RENDER)) continue;
        FT_GlyphSlot g = face->glyph;
        int adv = g->advance.x >> 6;
        if (maxw > 0 && (x - x0) + adv > maxw) break;

        for (unsigned r = 0; r < g->bitmap.rows; r++) {
            for (unsigned c = 0; c < g->bitmap.width; c++) {
                int a = g->bitmap.buffer[r * g->bitmap.pitch + c];
                if (!a) continue;
                int px = x + g->bitmap_left + c;
                int py = y - g->bitmap_top + r;
                if (px < 0 || py < 0 || px >= (int)W || py >= (int)H) continue;
                u32 bg = back[py * W + px];
                int br = (bg >> 16) & 255, bgc = (bg >> 8) & 255, bb = bg & 255;
                int rr = (cr * a + br * (255 - a)) / 255;
                int gg = (cg * a + bgc * (255 - a)) / 255;
                int bl = (cb * a + bb * (255 - a)) / 255;
                back[py * W + px] = (rr << 16) | (gg << 8) | bl;
            }
        }
        x += adv;
    }
}

/* ---------- file list ---------- */
typedef struct {
    char name[256];
    int isdir;
    long long size;
} Entry;

static Entry entries[MAX_ENTRIES];
static int count = 0, sel = 0, top = 0;
static char path[1024] = "/dev_hdd0";   /* empty string = device list */
static char msg[128] = "";

static int cmp_entry(const void *a, const void *b)
{
    const Entry *x = a, *y = b;
    if (x->isdir != y->isdir) return y->isdir - x->isdir;
    return strcasecmp(x->name, y->name);
}

/* returns 0 on success, -1 if the folder can't be opened */
static int load_dir(void)
{
    count = 0; sel = 0; top = 0;

    if (path[0] == 0) {
        static const char *roots[] = {
            "dev_hdd0", "dev_usb000", "dev_usb001", "dev_usb002",
            "dev_bdvd", "dev_flash", NULL
        };
        for (int i = 0; roots[i]; i++) {
            strcpy(entries[count].name, roots[i]);
            entries[count].isdir = 1;
            entries[count].size = 0;
            count++;
        }
        return 0;
    }

    DIR *d = opendir(path);
    if (!d) return -1;

    struct dirent *e;
    while ((e = readdir(d)) && count < MAX_ENTRIES) {
        if (!strcmp(e->d_name, ".") || !strcmp(e->d_name, "..")) continue;

        char full[1400];
        snprintf(full, sizeof(full), "%s/%s", path, e->d_name);

        Entry *en = &entries[count];
        strncpy(en->name, e->d_name, 255);
        en->name[255] = 0;

        struct stat st;
        if (stat(full, &st) == 0) {
            en->isdir = S_ISDIR(st.st_mode) ? 1 : 0;
            en->size = st.st_size;
        } else {
            en->isdir = 0;
            en->size = 0;
        }
        count++;
    }
    closedir(d);
    qsort(entries, count, sizeof(Entry), cmp_entry);
    return 0;
}

static void go_up(void)
{
    if (path[0] == 0) return;
    char *p = strrchr(path, '/');
    if (!p || p == path) path[0] = 0;
    else *p = 0;
    msg[0] = 0;
    load_dir();
}

static void enter_selected(void)
{
    if (count == 0) return;
    Entry *en = &entries[sel];

    if (!en->isdir) {
        snprintf(msg, sizeof(msg), "File: %s (extract/open comes in the next step)", en->name);
        return;
    }

    char old[1024];
    strcpy(old, path);
    if (path[0] == 0) snprintf(path, sizeof(path), "/%s", en->name);
    else {
        size_t l = strlen(path);
        snprintf(path + l, sizeof(path) - l, "/%s", en->name);
    }
    msg[0] = 0;

    if (load_dir() != 0) {
        strcpy(path, old);
        load_dir();
        snprintf(msg, sizeof(msg), "Cannot open this folder");
    }
}

static void fmt_size(long long s, char *out, size_t n)
{
    if (s < 1024) snprintf(out, n, "%lld B", s);
    else if (s < 1024 * 1024) snprintf(out, n, "%.1f KB", s / 1024.0);
    else if (s < 1024LL * 1024 * 1024) snprintf(out, n, "%.1f MB", s / 1048576.0);
    else snprintf(out, n, "%.2f GB", s / 1073741824.0);
}

/* ---------- UI ---------- */
static int visible_rows(void)
{
    return (H - S(80) - S(50)) / S(34);
}

static void draw_ui(void)
{
    fill_rect(0, 0, W, H, COL_BG);

    /* header */
    fill_rect(0, 0, W, S(80), COL_GREEN);
    draw_text(S(24), S(34), "MouhArchiver", 0xFFFFFF, 0);
    draw_text(S(24), S(66), path[0] ? path : "/ (devices)", 0xE6F2D6, W - S(48));

    /* rows */
    int rows = visible_rows();
    int rh = S(34);
    for (int i = 0; i < rows; i++) {
        int idx = top + i;
        if (idx >= count) break;
        int y = S(80) + i * rh;

        u32 bg = (idx == sel) ? COL_DARKGRN : ((i & 1) ? COL_ROW_B : COL_ROW_A);
        fill_rect(0, y, W, rh, bg);

        Entry *en = &entries[idx];
        int base = y + rh - S(10);

        /* icon: folder = yellow square, file = grey square */
        fill_rect(S(24), y + S(8), S(18), S(18), en->isdir ? COL_FOLDER : COL_DIM);

        draw_text(S(56), base, en->name, COL_TEXT, W - S(56) - S(200));

        if (!en->isdir) {
            char sz[32];
            fmt_size(en->size, sz, sizeof(sz));
            draw_text(W - S(24) - text_width(sz), base, sz, COL_DIM, 0);
        }
    }

    /* footer */
    fill_rect(0, H - S(50), W, S(50), 0x141A17);
    const char *hint = msg[0] ? msg : "X: open   O / Triangle: back   L1/R1: jump   START: exit";
    draw_text(S(24), H - S(16), hint, msg[0] ? COL_FOLDER : COL_DIM, W - S(48));

    char cnt[32];
    snprintf(cnt, sizeof(cnt), "%d/%d", count ? sel + 1 : 0, count);
    draw_text(W - S(24) - text_width(cnt), S(66), cnt, 0xFFFFFF, 0);
}

/* ---------- input ---------- */
static int running = 1;

static void sys_cb(u64 status, u64 param, void *usrdata)
{
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) running = 0;
}

static int fire(int down, int *cnt)
{
    if (!down) { *cnt = 0; return 0; }
    (*cnt)++;
    return (*cnt == 1) || (*cnt > 20 && (*cnt % 4) == 0);
}

static void handle_input(void)
{
    static int c_up, c_dn, p_x, p_o, p_t, p_l, p_r;

    padInfo pi;
    padData pd;
    ioPadGetInfo(&pi);
    if (!pi.status[0]) return;
    ioPadGetData(0, &pd);

    if (fire(pd.BTN_DOWN, &c_dn) && sel < count - 1) sel++;
    if (fire(pd.BTN_UP, &c_up) && sel > 0) sel--;

    if (pd.BTN_R1 && !p_r) { sel += 10; if (sel > count - 1) sel = count - 1; if (sel < 0) sel = 0; }
    if (pd.BTN_L1 && !p_l) { sel -= 10; if (sel < 0) sel = 0; }

    if (pd.BTN_CROSS && !p_x) enter_selected();
    if ((pd.BTN_CIRCLE && !p_o) || (pd.BTN_TRIANGLE && !p_t)) go_up();
    if (pd.BTN_START) running = 0;

    p_x = pd.BTN_CROSS; p_o = pd.BTN_CIRCLE; p_t = pd.BTN_TRIANGLE;
    p_l = pd.BTN_L1; p_r = pd.BTN_R1;

    /* keep the selection on screen */
    int rows = visible_rows();
    if (sel < top) top = sel;
    if (sel >= top + rows) top = sel - rows + 1;
    if (top < 0) top = 0;
}

int main(int argc, char *argv[])
{
    (void)argc; (void)argv;

    init_screen();
    init_font();
    ioPadInit(7);
    sysUtilRegisterCallback(0, sys_cb, NULL);

    if (load_dir() != 0) { path[0] = 0; load_dir(); }

    while (running) {
        sysUtilCheckCallback();
        handle_input();
        draw_ui();
        flip();
    }

    gcmSetWaitFlip(ctx);
    ioPadEnd();
    sysUtilUnregisterCallback(0);
    return 0;
}
